#!/usr/bin/env node

const JSZip = require('jszip');
const fs = require('fs');
const path = require('path');

async function createTestEpub() {
    const zip = new JSZip();
    
    // Mimetype (debe ser el primer archivo, sin compresión)
    zip.file('mimetype', 'application/epub+zip');
    
    // META-INF/container.xml
    const containerXml = `<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
    <rootfiles>
        <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
    </rootfiles>
</container>`;
    zip.folder('META-INF').file('container.xml', containerXml);
    
    // OEBPS/content.opf
    const contentOpf = `<?xml version="1.0" encoding="UTF-8"?>
<package version="3.0" xmlns="http://www.idpf.org/2007/opf" unique-identifier="bookid">
    <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
        <dc:identifier id="bookid">test-epub-001</dc:identifier>
        <dc:title>Test EPUB for VS Code Extension</dc:title>
        <dc:creator>EPUB Editor Tests</dc:creator>
        <dc:language>es</dc:language>
        <meta property="dcterms:modified">2024-12-28T10:00:00Z</meta>
    </metadata>
    <manifest>
        <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
        <item id="chapter1" href="Text/chapter1.xhtml" media-type="application/xhtml+xml"/>
        <item id="chapter2" href="Text/chapter2.xhtml" media-type="application/xhtml+xml"/>
        <item id="styles" href="Styles/style.css" media-type="text/css"/>
    </manifest>
    <spine>
        <itemref idref="chapter1"/>
        <itemref idref="chapter2"/>
    </spine>
</package>`;
    zip.folder('OEBPS').file('content.opf', contentOpf);
    
    // OEBPS/nav.xhtml
    const navXhtml = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops">
<head>
    <title>Navegación</title>
    <link rel="stylesheet" type="text/css" href="Styles/style.css"/>
</head>
<body>
    <nav epub:type="toc">
        <h1>Tabla de Contenidos</h1>
        <ol>
            <li><a href="Text/chapter1.xhtml">Capítulo 1: Introducción</a></li>
            <li><a href="Text/chapter2.xhtml">Capítulo 2: Funcionalidades</a></li>
        </ol>
    </nav>
</body>
</html>`;
    zip.folder('OEBPS').file('nav.xhtml', navXhtml);
    
    // OEBPS/Text/chapter1.xhtml
    const chapter1 = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Capítulo 1: Introducción</title>
    <link rel="stylesheet" type="text/css" href="../Styles/style.css"/>
</head>
<body>
    <h1>Capítulo 1: Introducción</h1>
    <p>Este es un EPUB de prueba para el <strong>EPUB Editor</strong> de VS Code.</p>
    <p>En este capítulo vamos a probar las funcionalidades básicas de edición.</p>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
    <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
</body>
</html>`;
    zip.folder('OEBPS').folder('Text').file('chapter1.xhtml', chapter1);
    
    // OEBPS/Text/chapter2.xhtml
    const chapter2 = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Capítulo 2: Funcionalidades</title>
    <link rel="stylesheet" type="text/css" href="../Styles/style.css"/>
</head>
<body>
    <h1>Capítulo 2: Funcionalidades</h1>
    <p>En este capítulo exploraremos las <em>funcionalidades avanzadas</em> del editor.</p>
    <h2>Características principales:</h2>
    <ul>
        <li>Edición de archivos XHTML</li>
        <li>Modificación de estilos CSS</li>
        <li>Integración con IA para mejora de texto</li>
        <li>Sistema de respaldo automático</li>
        <li>Guardado manual y automático</li>
    </ul>
    <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
    <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.</p>
</body>
</html>`;
    zip.folder('OEBPS').folder('Text').file('chapter2.xhtml', chapter2);
    
    // OEBPS/Styles/style.css
    const styleCss = `/* Estilos para el EPUB de prueba */
body {
    font-family: 'Georgia', serif;
    line-height: 1.6;
    margin: 1em;
    color: #333;
    background-color: #fafafa;
}

h1 {
    color: #2c3e50;
    border-bottom: 2px solid #3498db;
    padding-bottom: 0.5em;
    margin-bottom: 1em;
}

h2 {
    color: #34495e;
    margin-top: 1.5em;
}

p {
    text-align: justify;
    margin-bottom: 1em;
}

strong {
    color: #e74c3c;
    font-weight: bold;
}

em {
    color: #9b59b6;
    font-style: italic;
}

ul {
    margin-left: 2em;
}

li {
    margin-bottom: 0.5em;
}

/* Estilos para navegación */
nav ol {
    list-style-type: decimal;
    margin-left: 2em;
}

nav li {
    margin-bottom: 0.8em;
}

nav a {
    color: #3498db;
    text-decoration: none;
}

nav a:hover {
    text-decoration: underline;
}`;
    zip.folder('OEBPS').folder('Styles').file('style.css', styleCss);
    
    // Generar el archivo EPUB
    const content = await zip.generateAsync({
        type: 'nodebuffer',
        compression: 'DEFLATE',
        compressionOptions: { level: 9 },
        mimeType: 'application/epub+zip'
    });
    
    const outputPath = path.join(__dirname, 'test-epub-valid.epub');
    fs.writeFileSync(outputPath, content);
    
    console.log(`✅ EPUB válido creado: ${outputPath}`);
    console.log(`📊 Tamaño: ${(content.length / 1024).toFixed(2)} KB`);
    
    return outputPath;
}

createTestEpub().catch(console.error);
