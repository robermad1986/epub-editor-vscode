const JSZip = require('jszip');
const fs = require('fs');

console.log('Iniciando creación de EPUB...');

const zip = new JSZip();

// Mimetype
zip.file('mimetype', 'application/epub+zip');

// META-INF/container.xml
const containerXml = `<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
    <rootfiles>
        <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
    </rootfiles>
</container>`;
zip.folder('META-INF').file('container.xml', containerXml);

// OEBPS/content.opf
const contentOpf = `<?xml version="1.0" encoding="UTF-8"?>
<package version="3.0" xmlns="http://www.idpf.org/2007/opf" unique-identifier="bookid">
    <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
        <dc:identifier id="bookid">test-epub-001</dc:identifier>
        <dc:title>Test EPUB</dc:title>
        <dc:creator>Test</dc:creator>
        <dc:language>es</dc:language>
    </metadata>
    <manifest>
        <item id="chapter1" href="Text/chapter1.xhtml" media-type="application/xhtml+xml"/>
        <item id="styles" href="Styles/style.css" media-type="text/css"/>
    </manifest>
    <spine>
        <itemref idref="chapter1"/>
    </spine>
</package>`;
zip.folder('OEBPS').file('content.opf', contentOpf);

// OEBPS/Text/chapter1.xhtml
const chapter1 = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Test Chapter</title>
    <link rel="stylesheet" type="text/css" href="../Styles/style.css"/>
</head>
<body>
    <h1>Test Chapter</h1>
    <p>This is a test paragraph for EPUB editing tests.</p>
</body>
</html>`;
zip.folder('OEBPS').folder('Text').file('chapter1.xhtml', chapter1);

// OEBPS/Styles/style.css  
const styleCss = `body { font-family: serif; }`;
zip.folder('OEBPS').folder('Styles').file('style.css', styleCss);

console.log('Generando archivo...');

zip.generateAsync({type:'nodebuffer'}).then(function(content) {
    fs.writeFileSync('test-epub-valid.epub', content);
    console.log('✅ EPUB creado: test-epub-valid.epub');
}).catch(function(err) {
    console.error('❌ Error:', err);
});
