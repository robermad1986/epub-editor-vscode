#!/bin/bash

# EPUB Editor v0.1.7 - Functional Testing Script
# This script tests the core EPUB functionality step by step

echo "=========================================="
echo "EPUB Editor v0.1.7 - Functional Testing"
echo "Testing Date: $(date)"
echo "=========================================="

# Test environment
echo ""
echo "1. Testing Environment Verification"
echo "----------------------------------------"

# Check if VS Code is running with our extension
echo "VS Code version:"
code --version

echo ""
echo "Extension installed:"
code --list-extensions | grep epub

echo ""
echo "Available test files:"
ls -la *.epub 2>/dev/null || echo "No EPUB files found in current directory"

echo ""
echo "2. File System Provider Testing"
echo "----------------------------------------"

# Test if we can examine the EPUB structure
echo "Testing EPUB file structure (test-epub-valid.epub):"
if [ -f "test-epub-valid.epub" ]; then
    # Use Python to examine the EPUB structure as VS Code would
    python3 -c "
import zipfile
import os

epub_path = 'test-epub-valid.epub'
if os.path.exists(epub_path):
    with zipfile.ZipFile(epub_path, 'r') as epub_zip:
        files = epub_zip.namelist()
        print(f'EPUB contains {len(files)} files:')
        for file in sorted(files):
            info = epub_zip.getinfo(file)
            print(f'  {file} ({info.file_size} bytes)')
        
        # Test if we can read the key files
        print('\nTesting key file access:')
        try:
            mimetype = epub_zip.read('mimetype').decode('utf-8')
            print(f'  mimetype: {mimetype.strip()}')
        except:
            print('  mimetype: ERROR reading')
        
        try:
            container = epub_zip.read('META-INF/container.xml').decode('utf-8')
            print(f'  container.xml: {len(container)} characters')
        except:
            print('  container.xml: ERROR reading')
        
        try:
            opf = epub_zip.read('OEBPS/content.opf').decode('utf-8')
            print(f'  content.opf: {len(opf)} characters')
        except:
            print('  content.opf: ERROR reading')
else:
    print('test-epub-valid.epub not found')
"
else
    echo "test-epub-valid.epub not found"
fi

echo ""
echo "3. Extension Activation Testing"
echo "----------------------------------------"

# Test extension commands through VS Code CLI
echo "Testing extension activation by checking command availability:"

# This tests if the extension is properly loaded
echo "Available EPUB commands:"
code --list-extensions --show-versions | grep epub || echo "Extension not found in list"

echo ""
echo "4. Python Backend Testing"
echo "----------------------------------------"

# Test the AI backend
echo "Testing Python AI backend:"
if [ -f "out/src/python/openrouter_client.py" ]; then
    python3 out/src/python/openrouter_client.py --help
    echo ""
    echo "Testing model listing:"
    python3 out/src/python/openrouter_client.py --list-models
else
    echo "Python backend not found at expected location"
fi

echo ""
echo "5. File Modification Testing"
echo "----------------------------------------"

# Create a copy of the test EPUB for modification testing
if [ -f "test-epub-valid.epub" ]; then
    cp test-epub-valid.epub test-epub-editing.epub
    echo "Created test-epub-editing.epub for modification testing"
    
    # Test modifying the EPUB content
    echo "Testing EPUB content modification:"
    python3 -c "
import zipfile
import tempfile
import os

# Read the EPUB
with zipfile.ZipFile('test-epub-editing.epub', 'r') as zip_read:
    # Extract all files to temp directory
    temp_dir = tempfile.mkdtemp()
    zip_read.extractall(temp_dir)
    
    # Modify the chapter content
    chapter_path = os.path.join(temp_dir, 'OEBPS', 'chapter1.xhtml')
    if os.path.exists(chapter_path):
        with open(chapter_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Add a test modification
        modified_content = content.replace('<p>This is the first chapter.</p>', 
                                         '<p>This is the first chapter. [MODIFIED BY TEST]</p>')
        
        with open(chapter_path, 'w', encoding='utf-8') as f:
            f.write(modified_content)
        
        print('Modified chapter1.xhtml content')
        
        # Create a new EPUB with modifications
        with zipfile.ZipFile('test-epub-modified.epub', 'w', zipfile.ZIP_DEFLATED) as zip_write:
            for root, dirs, files in os.walk(temp_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, temp_dir)
                    zip_write.write(file_path, arcname)
        
        print('Created test-epub-modified.epub with changes')
    else:
        print('chapter1.xhtml not found in expected location')
    
    # Cleanup
    import shutil
    shutil.rmtree(temp_dir)
"
else
    echo "test-epub-valid.epub not found for modification testing"
fi

echo ""
echo "6. Extension Integration Testing"
echo "----------------------------------------"

# Test VS Code integration
echo "Testing VS Code integration:"
echo "Current workspace folders:"
code --status 2>/dev/null || echo "VS Code status not available"

echo ""
echo "Testing complete!"
echo "=========================================="

# Summary
echo ""
echo "TESTING SUMMARY:"
echo "- Environment: Checked VS Code and extension installation"
echo "- File System: Verified EPUB file structure and accessibility"
echo "- Python Backend: Tested AI service functionality"
echo "- File Modification: Tested EPUB content editing capability"
echo "- Integration: Checked VS Code workspace integration"
echo ""
echo "Next steps: Manual testing of VS Code commands and UI interaction"
