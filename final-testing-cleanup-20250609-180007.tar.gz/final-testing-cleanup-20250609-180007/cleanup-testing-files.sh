#!/bin/zsh

# Script de limpieza de archivos de testing - EPUB Editor v0.1.7
# Elimina archivos temporales de testing manteniendo solo los esenciales

echo "🧹 Iniciando limpieza de archivos de testing..."
echo "Fecha: $(date)"
echo "================================================"

# Crear backup de seguridad antes de eliminar
echo "\n📦 Creando backup de seguridad..."
backup_dir="testing-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$backup_dir"

# Lista de archivos a eliminar
files_to_remove=(
    # Scripts de testing temporales
    "test-complete-functionality.sh"
    "test-core-commands.py" 
    "test-epub-functionality.sh"
    "test-performance-final.py"
    "test-vscode-integration.py"
    "test-extension.js"
    "create-simple-epub.js"
    "create-test-epub.js"
    
    # Documentos de testing temporales
    "test-core-functionality.md"
    "test-create-epub.md"
    "test-epub-functionality.md"
    "test-save-functionality.md"
    "TEST-PLAN-v0.1.7.md"
    "TESTING-PLAN-EXECUTION.md"
    "TESTING-STATUS-REPORT.md"
    
    # EPUBs de testing duplicados/temporales
    "test-epub-editing.epub"
    "test-epub-modification.epub"
    "test-epub-modification.epub.modified"
    "test-epub-save.epub"
    "test-simple.epub"
    "test.epub.mimetype"
    
    # Versiones antiguas
    "epub-editor-0.1.6.vsix"
    
    # Archivos temporales
    "prompt.md"
    "CLEANUP-SUMMARY.md"
    "SAVE-FUNCTIONALITY-COMPLETE.md"
)

# Hacer backup y eliminar archivos
removed_count=0
backed_up_count=0

for file in "${files_to_remove[@]}"; do
    if [ -f "$file" ]; then
        echo "📋 Procesando: $file"
        
        # Hacer backup
        cp "$file" "$backup_dir/" 2>/dev/null && {
            echo "  ✅ Backup creado"
            backed_up_count=$((backed_up_count + 1))
        }
        
        # Eliminar archivo
        rm "$file" && {
            echo "  🗑️  Eliminado"
            removed_count=$((removed_count + 1))
        } || {
            echo "  ❌ Error al eliminar"
        }
    else
        echo "⚠️  No encontrado: $file"
    fi
done

echo "\n================================================"
echo "📊 Resumen de limpieza:"
echo "  - Archivos respaldados: $backed_up_count"
echo "  - Archivos eliminados: $removed_count"
echo "  - Backup guardado en: $backup_dir"

# Mostrar archivos que permanecen
echo "\n📁 Archivos principales que permanecen:"
ls -la *.md *.json *.vsix *.epub 2>/dev/null | head -20

echo "\n✅ Limpieza completada!"
echo "💡 Tip: Si necesitas recuperar algún archivo, está en $backup_dir"
